#include "Arduino.h"
#include "SystemEnums.h"
#include "DisplayOLED.h"
#include "SensorManager.h"
#include "TrafficLight.h"
#include "NBIoT.h"
#include "Globals.h"

#ifndef detectSystem_h
#define detectSystem_h

class DetectSystem {
private:
  SystemStatus status = SYS_INIT;
  SystemStatus lastStatus = SYS_INIT;
  unsigned long prevMillis = 0;

public:
  SystemStatus getStatus() {
    return this->status;
  }

  void set(SystemStatus status) {
    if (status == this->lastStatus) {
      return;
    }

    this->lastStatus = status;
    this->status = status;

    Serial.println(STATUS_STR[status]);
  }

  bool is(SystemStatus targetStatus) {
    return this->status == targetStatus;
  }

  void setPublishMsg() {
    if (this->status == SYS_RUNNING) {
      sensorManager.sensorStatusX4 |= ~(1 << 3);  // status = true, running
    } else {
      sensorManager.sensorStatusX4 &= ~(1 << 3);  // status = false, stopped
    }

    publishMsgContent = "{\"csq\":";
    publishMsgContent.concat(nbiot.CSQ);
    publishMsgContent.concat(",");
    publishMsgContent.concat("\"cgatt\":");
    publishMsgContent.concat(nbiot.CGATT);
    publishMsgContent.concat(",");
    publishMsgContent.concat("\"cereg\":\"");
    publishMsgContent.concat(nbiot.CEREG);
    publishMsgContent.concat("\"");
    publishMsgContent.concat(",");
    publishMsgContent.concat("\"din\":");
    publishMsgContent.concat(String(sensorManager.sensorStatusX8));
    publishMsgContent.concat(",");
    publishMsgContent.concat("\"dout\":");
    publishMsgContent.concat(String(sensorManager.sensorStatusX4));
    publishMsgContent.concat("}");

    int contentLen = publishMsgContent.length();

    publishMsgPrepare = "AT+QMTPUB=0,0,0,0,rgt/";
    publishMsgPrepare.concat(nbiot.IMEI);
    publishMsgPrepare.concat("/in,");
    publishMsgPrepare.concat(String(contentLen));

    publishMsgForce = publishMsgPrepare;
    publishMsgForce.concat(",");
    publishMsgForce.concat(publishMsgContent);
  }
};

extern DetectSystem detectSystem;

#endif
